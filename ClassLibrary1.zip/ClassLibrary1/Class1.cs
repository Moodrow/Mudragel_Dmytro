﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClassLibrary1
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void NotStringIncluded1()
        {
            List<object> resultList = ListFilterer.GetIntegersFromList(new List<object>() { 1, 2, 'a', 'b', "aass", '1', "123", 231 });
            Assert.AreEqual(resultList, new List<object>() { 1, 2, 231 });
        }

        [Test]
        public void NotStringIncluded2()
        {
            List<object> resultList = ListFilterer.GetIntegersFromList(new List<object>() { 1, 2, 'a', 'b', "aass",67,456,4,"opa","ttt", '1', "123", 231 });
            Assert.AreEqual(resultList, new List<object>() { 1, 2, 67, 456, 4, 231 });
        }

        static class ListFilterer
        {
            public static List<object> GetIntegersFromList(List<object> inputList)
            {
                int a = inputList.Count();
                int i = 0;
                int count = 0;
                while (i<a && count<a) 
                {
                    if (inputList[i].GetType() != a.GetType())
                    {
                        inputList.RemoveAt(i);
                        count++;
                    } else
                    {
                        count++;
                        i++;
                    }

                }
                return inputList;
            }
        }
    }
}
