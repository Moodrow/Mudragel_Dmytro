﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClassLibrary1
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void NotStringIncluded1()
        {
            Assert.AreEqual(RecursiveSum(3453486),6);
        }

        [Test]
        public void NotStringIncluded2()
        {
            Assert.AreEqual(RecursiveSum(2),2);
        }


        public int  RecursiveSum(int inputNumber)
        {
            if (inputNumber.ToString().Length == 1)
            {
                return inputNumber;
            }
            else
            {
                int sum = 0;
                int length = inputNumber.ToString().Length;
                for (int i = 0; i < length; i++)
                {
                    sum += inputNumber % 10;
                    inputNumber = inputNumber / 10;
                }
                return RecursiveSum(sum);
            } 
        }
    }
}
