﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ClassLibrary1
{
    [TestFixture]
    public class Class1
    {
        [Test]
        public void NotStringIncluded1()
        {
            Assert.AreEqual(first_non_repeating_letter("ssssss"),"");
        }

        [Test]
        public void NotStringIncluded2()
        {
            Assert.AreEqual(first_non_repeating_letter("sTReSSt"),"R");
        }

       
        public string first_non_repeating_letter(string inputString)
        {
            for (int i = 0; i < inputString.Length; i++)
            {
                string temp = ((inputString).ToLower()).Remove(i,1);
                if (!temp.Contains(inputString.ToLower()[i]))
                {
                    return inputString[i].ToString();
                }
            }
            return "";
        }
        
    }
}
